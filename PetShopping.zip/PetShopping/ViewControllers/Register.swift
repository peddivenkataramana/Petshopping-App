 

import UIKit

class Register: UIViewController {
    
    @IBOutlet weak var name: UITextField!
   
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBAction func onRegisterButtonPress(_ sender: Any) {
        
        let name = self.name.text!
        let email = self.email.text!
        let password = self.password.text!
        
        if name.isEmpty || email.isEmpty || password.isEmpty {
            showAlert(message: "Please enter all the fields")
        }else {
            
            
            
            users.append(User(name: name, email: email, password: password))
            
            
            
            let alertController = UIAlertController(title: "Registration Successful", message: "Your registration was successful!", preferredStyle: .alert)
            
            
            let okAction = UIAlertAction(title: "OK", style: .default) { [weak self] (action) in

                self?.navigationController?.popViewController(animated: true)
            }
            alertController.addAction(okAction)
            
            
            self.present(alertController, animated: true, completion: nil)
            
            
        }
       
    }

   
    
    func showAlert(message:String) {
    
               let alert = UIAlertController(title: "Message", message: message, preferredStyle: UIAlertController.Style.alert)

               alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))

               self.present(alert, animated: true, completion: nil)
    }
    
}

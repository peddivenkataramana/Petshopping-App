import UIKit

class Cart: UIViewController, UITableViewDataSource, UITableViewDelegate {
 
   @IBOutlet weak var tableView: UITableView!
 
   var selectedCategories = [String]()
   var products = [[String]]()
   var amounts = [Int]()
   
    @IBOutlet weak var payButton: UIButton!
    
   override func viewDidLoad() {
       super.viewDidLoad()
       self.tableView.dataSource = self
       self.tableView.delegate = self
       
       for product in products {
           for _ in product {
               amounts.append(Int.random(in: 10...100))
           }
       }
       
       var totalAmount = 0
       
       for item in amounts {
           totalAmount += item
       }
       self.payButton.setTitle("Pay Toal -  $\(totalAmount) ", for: .normal)
   }
   
   func numberOfSections(in tableView: UITableView) -> Int {
       return self.selectedCategories.count
   }
 
   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return self.products[section].count
   }
 
   func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
       return self.selectedCategories[section]
   }
 
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
       
       let productName = self.products[indexPath.section][indexPath.row]
       
       let price =  amounts[indexPath.row]
       
       cell.textLabel?.text = "$\(price) - \(productName)"
        
       return cell
   }
 
}

 

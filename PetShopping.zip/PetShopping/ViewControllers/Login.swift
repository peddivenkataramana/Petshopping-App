
import UIKit

class Login: UIViewController {
    
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBAction func loginButtonClick(_ sender: Any) {
      
        let email = self.email.text!
        let password = self.password.text!
        
        if(!email.isEmpty || !password.isEmpty) {  // when not empty
            
            for user in users {
                
                    if user.email == email && user.password == password {
                        // Email and password match a user in the array, so login successful
 
                        self.performSegue(withIdentifier: "HomeSegue", sender: self)
                    
                        
                        return
                    }
            }
                
            
            
                 showAlert()
                print("Login failed")
            
            
        }else {
            showAlertEnterDetails()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "HomeSegue" {
            segue.destination .modalPresentationStyle = .fullScreen
        }
    }

    func showAlertEnterDetails() {
    
               let alert = UIAlertController(title: "Message", message: "Please enter details", preferredStyle: UIAlertController.Style.alert)

               alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))

               self.present(alert, animated: true, completion: nil)
    }
    
    
    
    func showAlert() {
    
               let alert = UIAlertController(title: "Message", message: "Login Failed", preferredStyle: UIAlertController.Style.alert)

               alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))

               self.present(alert, animated: true, completion: nil)
    }
   
    
}

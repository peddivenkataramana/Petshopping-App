import UIKit

 
class Home: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var nextButton: UIButton!

    var selectedSubcategories: [String: Set<String>] = [:]
    var selectedCategories: Set<String> = []

    var categories = ["Food", "Accessories", "Bedding", "Grooming"]

    var products = [
        "Food": ["Royal Canin", "Hill's Science Diet", "Purina Pro Plan"],
        "Accessories": ["Collars", "Leashes", "Toys", "Beds"],
        "Bedding": ["Cushions", "Blankets", "Pillows"],
        "Grooming": ["Shampoo", "Conditioner", "Brush", "Nail Clipper"]
    ]

    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "petCell")

        nextButton.isHidden = true
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return categories.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let category = categories[section]
        return products[category]?.count ?? 0
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return categories[section]
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "petCell", for: indexPath)

        let category = categories[indexPath.section]
        if let subcategory = products[category]?[indexPath.row] {
            let selected = selectedSubcategories[category]?.contains(subcategory) ?? false
            
            if(selected) {
                cell.imageView?.image =  UIImage(named: "checked")
            }else {
                cell.imageView?.image =  UIImage(named: "uncheck")
            }

            cell.textLabel?.text = subcategory
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let category = categories[indexPath.section]
        if var selectedSubcategoriesForCategory = selectedSubcategories[category] {
            let subcategory = products[category]![indexPath.row]
            if selectedSubcategoriesForCategory.contains(subcategory) {
                selectedSubcategoriesForCategory.remove(subcategory)
                if selectedSubcategoriesForCategory.isEmpty {
                    selectedSubcategories[category] = nil
                    selectedCategories.remove(category)
                } else {
                    selectedSubcategories[category] = selectedSubcategoriesForCategory
                }
            } else {
                selectedSubcategoriesForCategory.insert(subcategory)
                selectedSubcategories[category] = selectedSubcategoriesForCategory
            }
        } else {
            let subcategory = products[category]![indexPath.row]
            selectedSubcategories[category] = Set([subcategory])
            selectedCategories.insert(category)
        }
        tableView.reloadData()
        hideShowNextButton()
    }

    func hideShowNextButton() {
        nextButton.isHidden = selectedSubcategories.isEmpty
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
             guard let cart = segue.destination as? Cart else {
                return
            }
           
            // Transform the dictionary of selected subcategories into a 2D array of products
            let products = selectedSubcategories.map { (key, value) in
                Array(value)
            }
            
            // Pass data
            cart.selectedCategories = Array(selectedCategories)
            cart.products = products
         
    }

    
}

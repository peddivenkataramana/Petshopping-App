
import UIKit

class PaymentScreen: UIViewController {


@IBOutlet weak var name: UITextField!

@IBOutlet weak var number: UITextField!

@IBOutlet weak var cvv: UITextField!

@IBAction func onPay(_ sender: Any) {
    
    
    let name = self.name.text!
    let number = self.number.text!
    let cvv = self.cvv.text!
    
    if name.isEmpty || number.isEmpty || cvv.isEmpty {
        showAlert(message: "Please enter all the details")
        return
    }else {
        showAlert(message: "Payment Success 😊")
    }
    
}
   
    
    func showAlert(message:String) {
    
               let alert = UIAlertController(title: "Message", message: message, preferredStyle: UIAlertController.Style.alert)

               alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))

               self.present(alert, animated: true, completion: nil)
    }
}

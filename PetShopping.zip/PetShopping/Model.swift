 
import Foundation

struct User {
    var name:String
    var email:String
    var password:String
}

var users = [User]()

